import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceattendacerealtime-d7e77-default-rtdb.firebaseio.com/"
})

ref = db.reference('Students')

data = {
    "321654":
        {
            "name": "sourabh patidaar",
            "major": "IOT",
            "starting_year": 2021,
            "total_attendance": 1,
            "standing": "P",
            "year": 3,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "852741":
        {
            "name": "Deepanshu Rana",
            "major": "Blockchain",
            "starting_year": 2021,
            "total_attendance": 12,
            "standing": "P",
            "year": 3,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "963852":
        {
            "name": "Aman Singh",
            "major": "Cyber security",
            "starting_year": 2020,
            "total_attendance": 2,
            "standing": "P",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
"425255":
        {
            "name": "Pavitra Gupta",
            "major": "Computer Science",
            "starting_year": 2020,
            "total_attendance": 2,
            "standing": "P",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        }
}

for key, value in data.items():
    ref.child(key).set(value)